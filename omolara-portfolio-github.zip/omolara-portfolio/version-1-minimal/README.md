# Omolara Adeniyi-Jinadu: Portfolio (Version 1, minimal)

A plain website with no build step. Double-click `index.html` to preview it on your computer.

## Put it live with GitHub Pages
1. Sign in at github.com (create a free account if you need one).
2. Click **+** (top right) then **New repository**. Name it `YOUR-USERNAME.github.io`, which gives the cleanest address. Choose **Public**, then **Create repository**.
3. On the new repository page click **uploading an existing file**. Open this folder on your computer, select everything inside it (`index.html`, the `assets` folder, `README.md`) and drag it onto the page. Click **Commit changes**.
4. Go to **Settings, then Pages**. Under "Build and deployment" set Source to **Deploy from a branch**, Branch **main**, folder **/ (root)**, and click **Save**.
5. Wait a minute or two and refresh the Pages screen. Your site is at `https://YOUR-USERNAME.github.io`.

If you use a different repository name, the site lives at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/` and works the same way.

## Updating it later
- **New CV:** replace `assets/Omolara_Adeniyi-Jinadu_CV.pdf` with the new file, keeping the same file name.
- **New photo:** replace `assets/omolara.jpg`, keeping the same file name.
- **Wording changes:** open `index.html` on GitHub and click the pencil icon.

## Vercel instead
If you prefer Vercel, import the repository at vercel.com/new and click Deploy. No settings are needed.

## Privacy note
The page and the CV show your email address and phone number. In a public repository they are visible to anyone and can be indexed by search engines.
